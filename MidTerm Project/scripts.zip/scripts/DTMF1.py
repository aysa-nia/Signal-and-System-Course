from scipy.io import wavfile as wav
import numpy as np
from matplotlib import pyplot as plt
import os



			
			

def DTMF(signal, rate):

    ##################################
              ####   write your code here   ####
    ##################################

    result = ''  # An example of your final result. it means you have found no key!
    
    ### PAY ATTENTION: you should return the string of what you have found

    
    ### a sample csv file is attached: 'Phase1-Label-Test-Sample.csv'
    ### ba sure that you are saving data in the right format

    ### it's obvious that your score is loss! so the closer to zero, the better algorithm.

    return result
